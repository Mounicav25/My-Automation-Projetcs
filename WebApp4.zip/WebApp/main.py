from flask import Flask, render_template,json


app = Flask(__name__, template_folder='./templates')

@app.route('/kiranastores')
def home():
    english_grocery_loc = open('grocery.json')
    english_grocery_data = json.load(english_grocery_loc)
    telugu_grocery_loc = open('telugugrocery.json')
    telugu_grocery_data = json.load(telugu_grocery_loc)
    return render_template('child.html', english_data=english_grocery_data,telugu_data=telugu_grocery_data)

if __name__ == "__main__":
    app.run(host='10.2.235.127',port=5002, debug = True)