function displayItem(locator,lang){

           if(lang=='English'){
           list = english_data_json.groceries;
           document.getElementById("teluguItems").style.display = "none";
           document.getElementById(locator).style.display = "block";
           document.getElementById("teluguItems").innerHTML = "";
           }
           else{
           list = telugu_data_json.groceries;
           document.getElementById("englishItems").style.display = "none";
           document.getElementById(locator).style.display = "block";
           document.getElementById("englishItems").innerHTML = "";
           }

            for (var i = 0; i < list.length; i++){

           var node = document.createElement("div");
           node.classList.add("mystyle");
           node.classList.add("col-lg-3");
           node.classList.add("col-md-5");

           var checkbox = document.createElement('input');
           checkbox.type = "checkbox";
           checkbox.id = 'box-'+list[i]['item'];
           checkbox.name = list[i]['item'];
           checkbox.value = list[i]['item'];
           checkbox.onchange = function () { itemOnChange(this); };

           var label = document.createElement('label');
           label.classList.add("itemslabel");
           label.appendChild(document.createTextNode(list[i]['item']));

           var quantities = ["1","2","3","4","5"];
           var qty_dropdown = document.createElement('select');
           qty_dropdown.classList.add("qtydropdown");
           qty_dropdown.id = list[i]['item'];
           qty_dropdown.onchange = function () { ddOnChange(this); };

           for(const val of quantities)
           {
           var option = document.createElement('option');
           option.id=list[i]['item']+val;
           option.val = val;
           option.text = val+" kg";
           qty_dropdown.appendChild(option);
           }
           var cost = document.createElement('label');
           cost.id = 'item-'+list[i]['item'];
           cost.value = list[i]['price'];
           cost.appendChild(document.createTextNode('₹ ' +list[i]['price']));

           var subDiv = document.getElementById(locator).appendChild(node);
            subDiv.appendChild(checkbox);
            subDiv.appendChild(label);
            subDiv.appendChild(qty_dropdown);
            subDiv.appendChild(cost);
           }
       }

    function ddOnChange(e){
     var id = e.id;
     var value = e.value;
     var cost = document.getElementById("item-"+id).value;
     var res = value.split(" ");
     document.getElementById("item-"+id).innerHTML = "₹ " +res[0]*cost;
     }

function itemOnChange(e1){

   if(document.getElementById(e1.id).checked==true){
     checkedItems.push(e1.value);
    }
    else if(document.getElementById(e1.id).checked==false){

     checkedItems.splice(checkedItems.indexOf(e1.value),1);

    }
  }

function collectCheckboxes(){
    var doc = new jsPDF()
     var x = 10;
     var total_price = 0;

       for (var i = 0; i < checkedItems.length; i++){
              doc.text(checkedItems[i], 20, x)
              doc.text(document.getElementById(checkedItems[i]).value, 50, x)
              var cost = document.getElementById("item-"+checkedItems[i]).innerHTML;
              var res = cost.split(" ");
              doc.text(res[1], 70, x)
              total_price = total_price + parseInt(res[1]);
              x = x+10;
          }
         doc.text("------------", 70, x)
          x = x+5;
         doc.text(total_price.toString(), 70, x)
         doc.save('items.pdf')

}