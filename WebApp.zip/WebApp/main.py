from flask import Flask, render_template,json, send_file
from twilio.rest import Client
import os


app = Flask(__name__, template_folder='./templates')

@app.route('/kiranastores')
def home():
    myfile = "items.pdf"
    if os.path.isfile(myfile):
        os.remove(myfile)

    english_grocery_loc = open('./templates/input/grocery.json')
    english_grocery_data = json.load(english_grocery_loc)
    telugu_grocery_loc = open('./templates/input/telugugrocery.json')
    telugu_grocery_data = json.load(telugu_grocery_loc)
    return render_template('child.html', english_data=english_grocery_data,telugu_data=telugu_grocery_data)

@app.route('/return-files/items.pdf')
def return_files_tut():
	return send_file('items.pdf', attachment_filename='items.pdf')

@app.route('/sms')
def send_msg():
    account_sid = 'AC1c5a3d25261d8f4e49e6974ee2d75653'
    auth_token = 'abc64808d63a3197f24df62a1010b49c'
    client = Client(account_sid, auth_token)

    client.messages.create(
        body='Hello there!',
        media_url='http://3a90477d5e2e.ngrok.io/return-files/items.pdf',
        from_='whatsapp:+14155238886',
        to='whatsapp:+919787571759'

    )
    return "Order received"

if __name__ == "__main__":
    app.run(debug = True)