package com.helper.pages;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class APIPage {

	public String getAPI(String link) throws Exception {
    	String output=null;
    	Response res=null;
    try {
    	res = RestAssured.given()

    			       .when().get(link);
    	if(res.statusCode()==200) {
    		output = res.asString();
    
    	}else output="API not success, Response Code : "+String.valueOf (res.statusCode());
    	}catch(Exception e) {
    	   output="API is not working";
    	}
		return output;	
	
	}
    	
}
