package com.regression;

import org.testng.annotations.Test;

import com.helper.pages.APIPage;

public class API {

	APIPage api;
	
	public API() {
		api = new APIPage();				
	}
	
	@Test(groups= {"1unit"})
	public void getNextBirthdayForSpecificUnit() throws Exception {
		String link = "https://lx8ssktxx9.execute-api.eu-west-1.amazonaws.com/Prod/next-birthday?dateofbirth="+System.getProperty("DOB")+"&unit="+System.getProperty("UNIT");
		System.out.println(api.getAPI(link));
	}
	
	@Test(groups= {"Allunit"})
	public void getNextBirthdayForAllUnit() throws Exception {
		String link1 = "https://lx8ssktxx9.execute-api.eu-west-1.amazonaws.com/Prod/next-birthday?dateofbirth="+System.getProperty("DOB")+"&unit=hour";
		String link2 = "https://lx8ssktxx9.execute-api.eu-west-1.amazonaws.com/Prod/next-birthday?dateofbirth="+System.getProperty("DOB")+"&unit=day";
		String link3 = "https://lx8ssktxx9.execute-api.eu-west-1.amazonaws.com/Prod/next-birthday?dateofbirth="+System.getProperty("DOB")+"&unit=week";
		String link4 = "https://lx8ssktxx9.execute-api.eu-west-1.amazonaws.com/Prod/next-birthday?dateofbirth="+System.getProperty("DOB")+"&unit=month";
		System.out.println(api.getAPI(link1));
		System.out.println(api.getAPI(link2));
		System.out.println(api.getAPI(link3));
		System.out.println(api.getAPI(link4));
	}
}
