function displayItems(slector,value) {
     var list = [];
     if(value == 'English'){
        list = english_grocery_list.groceries;
      }
      else{
        list = telugu_grocery_list.groceries;
        }
      for (var i = 0; i < list.length; i++){
          var node = document.createElement("div");
           node.classList.add("mystyle");
           node.classList.add("col-lg-3");
           node.classList.add("col-md-5");

           var checkbox = document.createElement('input');
           checkbox.type = "checkbox";
           checkbox.id = 'box-'+list[i]['item']
           checkbox.name = list[i]['item'];
           checkbox.value = list[i]['item'];
           checkbox.onchange = function () { itemOnChange(this); };

           var label = document.createElement('label');
           label.classList.add("itemslabel");
           label.appendChild(document.createTextNode(list[i]['item']));

           var quantities = ["1", "2", "3"];

           var select1 = document.createElement("select");
           select1.classList.add("quantitydropdown");
           select1.id = list[i]['item'];
           select1.onchange = function () { ddlOnChange(this); };
            for (const val of quantities) {
                var option = document.createElement("option");
                option.id = list[i]['item']+val;
                option.value = val;
                option.text = val+'kg';
                 select1.appendChild(option);
            }

            var cost = document.createElement('label');
            cost.id = 'item-'+list[i]['item'];
            cost.value = list[i]['price'];
            cost.appendChild(document.createTextNode('₹' +list[i]['price']));

            var subDiv = document.getElementById(slector).appendChild(node);
            subDiv.appendChild(checkbox);
            subDiv.appendChild(label);
            subDiv.appendChild(select1);
            subDiv.appendChild(cost);
       }

}

function ddlOnChange(e){
     var id = e.id;
     var value = e.value;
     var cost1 = document.getElementById("item-"+id).value;
     document.getElementById("item-"+id).innerHTML = "₹"+(value*cost1);
}

function itemOnChange(e1){

   if(document.getElementById(e1.id).checked==true){
     finalitems.itemslist.push({
        "item" : e1.value,
        "quantity"  : document.getElementById(e1.value).value,
        "price"       : document.getElementById("item-"+e1.value).value});
    }
    else{
    if(finalitems.itemslist.item == e1.value){
       finalitems.itemslist.remove(e1.value,1);
       }
    }
}

function collectCheckboxes(){
    var doc = new jsPDF()
     var x = 10;
     var finallist = finalitems.itemslist;
       for (var i = 0; i < finallist.length; i++){

              doc.text(finallist[i]['item'], 10, x)
          }
          document.getElementById("demo").innerHTML =finallist;

         doc.save('items.pdf')
}



